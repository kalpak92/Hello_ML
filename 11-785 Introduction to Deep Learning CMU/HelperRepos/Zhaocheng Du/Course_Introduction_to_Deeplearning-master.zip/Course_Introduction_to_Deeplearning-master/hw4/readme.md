hw4
