some code resources
