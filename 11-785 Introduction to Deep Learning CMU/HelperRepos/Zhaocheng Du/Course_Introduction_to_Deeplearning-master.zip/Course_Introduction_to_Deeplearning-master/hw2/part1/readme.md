write CNN based on numpy
