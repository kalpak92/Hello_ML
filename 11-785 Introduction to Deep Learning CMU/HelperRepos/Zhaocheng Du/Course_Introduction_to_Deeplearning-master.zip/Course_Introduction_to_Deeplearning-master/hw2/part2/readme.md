Face classification and verification
