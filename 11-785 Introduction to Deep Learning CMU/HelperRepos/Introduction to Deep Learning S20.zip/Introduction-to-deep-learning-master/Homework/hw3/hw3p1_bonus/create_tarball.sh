tar -cvf handin.tar --exclude=*pycache* mytorch hw3
