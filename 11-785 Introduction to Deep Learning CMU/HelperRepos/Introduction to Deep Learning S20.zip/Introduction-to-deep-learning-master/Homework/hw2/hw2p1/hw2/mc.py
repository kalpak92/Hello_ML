# Multiple Choice

# Return the answer to the multiple choice question in the handout.
# If you think option c is the correct answer,
# return 'c'

def question_1():
    # raise NotImplemented
    return 'b'

def question_2():
    # raise NotImplemented
    return 'd'

def question_3():
    # raise NotImplemented
    return 'b'

def question_4():
    # raise NotImplemented
    return 'a'

def question_5():
    # raise NotImplemented
    return 'a'
