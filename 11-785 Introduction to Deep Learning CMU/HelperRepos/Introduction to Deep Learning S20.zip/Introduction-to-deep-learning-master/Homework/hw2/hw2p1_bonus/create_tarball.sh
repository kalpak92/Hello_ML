rm -rf mytorch/__pycache__
tar -cvf handin.tar mytorch 
