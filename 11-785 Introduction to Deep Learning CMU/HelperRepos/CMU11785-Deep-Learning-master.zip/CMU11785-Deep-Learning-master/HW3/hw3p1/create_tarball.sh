tar -cvf handin.tar hw3 mytorch
